let points = 0;

function addPoints(amount) {
  points += amount;
  alert("You earned " + amount + " points! Total: " + points);
}